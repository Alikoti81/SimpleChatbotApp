package com.chatbotali.app

import android.content.Context
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject

class JavaScriptBridge(val ctx: Context, val webView: WebView) {
    @JavascriptInterface
    fun getResponse(message: String) : String {
        val msg = message.lowercase().trim()
        val resp = when {
            msg.contains("سلام") -> "سلام! من ChatbotAli هستم 😊 چطور می‌تونم کمکت کنم؟"
            msg.contains("چطوری") || msg.contains("حالت") -> "من عالی‌ام! تو چطوری؟"
            msg.contains("اسم") -> "اسم من ChatbotAli هست — خوشوقتم!"
            msg.contains("مرسی") || msg.contains("ممنون") -> "خواهش می‌کنم عزیزم ❤️"
            msg.contains("بای") || msg.contains("خدافظ") -> "خداحافظ! هر وقت خواستی برگرد."
            msg.contains("کمک") -> "بگو چه کاری از دستم برمیاد — من اینجام."
            msg.contains("ثروت") -> "برای جذب فراوانی، تمرکز کن و قدم‌های کوچک بردار."
            else -> "عالی! توضیح بیشتر بده تا بهتر کمکت کنم."
        }
        val obj = JSONObject()
        obj.put("reply", resp)
        return obj.toString()
    }
}
