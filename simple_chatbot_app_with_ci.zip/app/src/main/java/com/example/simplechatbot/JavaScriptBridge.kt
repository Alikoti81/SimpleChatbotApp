package com.example.simplechatbot

import android.content.Context
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject

class JavaScriptBridge(val ctx: Context, val webView: WebView) {
    // Simple rule-based responder
    @JavascriptInterface
    fun getResponse(message: String) : String {
        val msg = message.lowercase().trim()
        val resp = when {
            msg.contains("سلام") -> "سلام! چطور می‌تونم کمکت کنم؟"
            msg.contains("چطوری") || msg.contains("حالت") -> "من خوبم، ممنون! تو چطوری؟"
            msg.contains("اسم") -> "اسم من چی؟ من یه چت‌بات ساده‌ام."
            msg.contains("ممنون") || msg.contains("مرسی") -> "خواهش می‌کنم 😊"
            msg.contains("خدافظ") || msg.contains("بای") -> "خدانگهدار! هر وقت خواستی برگرد."
            msg.contains("کمک") -> "حتما! بگو چه کاری از دستم برمیاد."
            msg.contains("وقت") -> "متأسفم، ساعت رو ندارم؛ ولی همیشه وقت دارم که گوش بدم!"
            else -> "متوجه نشدم — می‌تونی به روش ساده‌تری بگی؟"
        }
        // return JSON string with reply
        val obj = JSONObject()
        obj.put("reply", resp)
        return obj.toString()
    }
}
